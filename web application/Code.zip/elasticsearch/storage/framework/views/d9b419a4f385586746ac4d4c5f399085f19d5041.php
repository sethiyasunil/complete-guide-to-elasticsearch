<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xs-6 col-xs-offset-3">
            <a href="/" class="btn btn-primary"><span class="glyphicon glyphicon-chevron-left"></span> Back</a>

            <h1><?php echo e($product['name']); ?></h1>

            <p><?php echo e($product['description']); ?></p>

            <a href="#" class="btn btn-success"><span class="glyphicon glyphicon-gbp"></span> Buy now for £<?php echo e($product['price']); ?>!</a>
            <a href="#" class="btn btn-info"><span class="glyphicon glyphicon-tag"></span> <?php echo e($product['quantity']); ?> In Stock</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>