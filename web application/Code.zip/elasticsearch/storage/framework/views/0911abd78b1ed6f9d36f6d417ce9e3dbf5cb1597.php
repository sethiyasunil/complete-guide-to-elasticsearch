<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xs-6 col-xs-offset-3">
            <div id="search-wrapper">
                <form action="/" method="GET" class="form-inline">
                    <div class="form-group">
                        <input type="text" name="query" class="form-control" placeholder="Enter your search query" value="<?php echo e(isset($query) ? $query : ''); ?>" />
                        <button type="submit" name="search-button" class="form-control glyphicon glyphicon-search"></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php if(!empty($query)): ?>
        <div class="row" id="filters-wrapper">
            <div class="col-xs-6 col-xs-offset-3">
                <strong>Price:</strong>

                <?php foreach($aggregations['aggregations']['price_ranges']['buckets'] as $bucket): ?>
                    <a href="?query=<?php echo e($query); ?>&page=<?php echo e($page); ?>&startprice=<?php echo e($bucket['from']); ?>&endprice=<?php echo e($bucket['to']); ?>&status=<?php echo e(isset($status) ? $status : ''); ?>&category=<?php echo e(isset($category) ? $category : ''); ?>" class="<?php echo e($bucket['from'] == $startPrice && $bucket['to'] == $endPrice ? 'active' : ''); ?>">
                        <?php echo e($bucket['from']); ?> - <?php echo e($bucket['to']); ?> (<?php echo e($bucket['doc_count']); ?>)
                    </a>
                <?php endforeach; ?>

                <br />

                <strong>Status:</strong>

                <?php foreach($aggregations['aggregations']['statuses']['buckets'] as $bucket): ?>
                    <a href="?query=<?php echo e($query); ?>&page=<?php echo e($page); ?>&status=<?php echo e(urlencode($bucket['key'])); ?>&startprice=<?php echo e(isset($startPrice) ? $startPrice : ''); ?>&endprice=<?php echo e(isset($endPrice) ? $endPrice : ''); ?>&category=<?php echo e(isset($category) ? $category : ''); ?>" class="<?php echo e($bucket['key'] == $status ? 'active' : ''); ?>">
                        <?php echo e(ucfirst($bucket['key'])); ?> (<?php echo e($bucket['doc_count']); ?>)
                    </a>
                <?php endforeach; ?>

                <br />

                <strong>Category:</strong>

                <?php foreach($aggregations['aggregations']['categories']['categories_count']['buckets'] as $bucket): ?>
                    <a href="?query=<?php echo e($query); ?>&page=<?php echo e($page); ?>&category=<?php echo e(urlencode($bucket['key'])); ?>&status=<?php echo e(isset($status) ? $status : ''); ?>&startprice=<?php echo e(isset($startPrice) ? $startPrice : ''); ?>&endprice=<?php echo e(isset($endPrice) ? $endPrice : ''); ?>" class="<?php echo e($bucket['key'] == $category ? 'active' : ''); ?>">
                        <?php echo e(ucfirst($bucket['key'])); ?> (<?php echo e($bucket['doc_count']); ?>)
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if(!empty($hits)): ?>
        <div class="row" id="results-text">
            <div class="col-xs-8 col-xs-offset-2">
                Displaying results <?php echo e(($from + 1)); ?> to <?php echo e($to); ?> of <?php echo e($total); ?>.
            </div>
        </div>

        <?php foreach($hits as $hit): ?>
            <div class="row">
                <div class="col-xs-8 col-xs-offset-2">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <a href="/product/view/<?php echo e($hit['_id']); ?>"><?php echo e($hit['_source']['name']); ?></a>
                        </div>
                        <div class="panel-body">
                            <p><?php echo e($hit['_source']['description']); ?></p>

                            <strong>Price:</strong> <?php echo e($hit['_source']['price']); ?>

                            <br />
                            <strong>Status:</strong> <?php echo e(ucfirst($hit['_source']['status'])); ?>

                            <br />
                            <strong>Categories:</strong>

                            <?php foreach($hit['_source']['categories'] as $c): ?>
                                <?php echo e($c['name']); ?> &nbsp;
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="row">
            <div class="pagination-wrapper col-xs-8 col-xs-offset-2">
                <nav>
                    <ul class="pagination">
                        <li>
                            <a href="?query=<?php echo e(urlencode($query)); ?>&page=<?php echo e(($page - 1)); ?>" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>

                        <?php for($i = 1; $i <= 10; $i++): ?>
                            <li <?php echo $i == $page ? 'class="active"' : ''; ?>><a href="?query=<?php echo e(urlencode($query)); ?>&page=<?php echo e($i); ?>&status=<?php echo e(isset($status) ? $status : ''); ?>&startprice=<?php echo e(isset($startPrice) ? $startPrice : ''); ?>&endprice=<?php echo e(isset($endPrice) ? $endPrice : ''); ?>&category=<?php echo e(isset($category) ? $category : ''); ?>"><?php echo e($i); ?></a></li>
                        <?php endfor; ?>

                        <li>
                            <a href="?query=<?php echo e(urlencode($query)); ?>&page=<?php echo e(($page + 1)); ?>" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    <?php elseif(isset($hits)): ?>
        <div class="row" id="no-results">
            <div class="col-xs-6 col-xs-offset-3">
                <p>No results!</p>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>